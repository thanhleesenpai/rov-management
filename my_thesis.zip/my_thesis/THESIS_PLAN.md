# KẾ HOẠCH VIẾT LẠI ĐỒ ÁN TỐT NGHIỆP
## Hệ thống quản lý vận hành ROV tích hợp trí tuệ nhân tạo

**Tài liệu tham chiếu:**
- Ví dụ mẫu: `DoAn_20225277_v3.pdf` (đồ án đặt vé sự kiện)
- Template: `SOICT_DATN_Application_VIE_Template/`
- Code thực tế: `d:\Code\rov-management\`

---

## TRẠNG THÁI HIỆN TẠI

| File | Dòng | Trạng thái | Vấn đề |
|------|------|-----------|---------|
| `DoAn.tex` | — | Cần sửa | `\AUTHOR{NGUYỄN VĂN ABC}` — placeholder |
| `0_2_Loi_cam_on.tex` | — | PLACEHOLDER | Chưa viết |
| `0_3_Tom_tat_noi_dung.tex` | — | PLACEHOLDER | Chưa viết |
| `0_4_Tom_tat_noi_dung_English.tex` | — | Cần kiểm tra | Có thể chưa viết |
| `1_Gioi_thieu.tex` | 40 | Gần xong | Cần check thuật ngữ |
| `2_Khao_sat.tex` | 112 | Cần sửa nhiều | UC dùng bullet list (phải là bảng), thuật ngữ cũ Trip/Dive |
| `3_Cong_nghe.tex` | 37 | Cần viết lại | Quá ngắn, thiếu Bảng 3.1 tổng quan, thiếu nhiều công nghệ |
| `4_Ket_qua_thuc_nghiem.tex` | 90 | Cần viết lại | Thiếu sơ đồ, thiếu bảng DB, thiếu screenshot UI, thiếu kết quả thực tế |
| `5_Giai_phap_dong_gop.tex` | 54 | Cần kiểm tra | Cần verify đúng pattern Bài toán→Giải pháp→Kết quả |
| `6_Ket_luan.tex` | 23 | Gần xong | Nhỏ nhưng OK |
| `Phu_luc_B.tex` | — | Cần sửa | UC specs dùng bullet (phải là bảng) |
| `Hinhve/` | — | Thiếu nhiều | Chỉ có 3 ảnh UC; thiếu toàn bộ screenshot UI, sơ đồ |
| `.bib` | — | Trống/rỗng | Chưa có tài liệu tham khảo nào |
| `Tu_viet_tat.tex` | — | Cần populate | Chưa có từ viết tắt |

---

## QUY TẮC PHONG CÁCH (rút ra từ ví dụ mẫu)

### Cách viết văn xuôi
- Đoạn văn thụt đầu dòng 15pt (đã cấu hình trong template)
- Viết **văn xuôi liên tục**, KHÔNG dùng bullet list trong thân chương (chỉ dùng bảng/hình)
- Mỗi công nghệ/phần: 2 đoạn — đoạn 1 trình bày bài toán + cơ chế, đoạn 2 so sánh với thay thế + lý do chọn
- Tham chiếu tài liệu dạng `\cite{key}` ngay sau tên công nghệ lần đầu xuất hiện

### Hình vẽ (Figures)
- Luôn đề cập trong văn bản TRƯỚC khi đặt figure: *"Hình X.Y mô tả..."*
- Caption ở **dưới** hình: `\caption{Mô tả ngắn gọn}`
- Label đặt sau caption để cross-reference: `\label{fig:ten_hinh}`
- Kích thước: `\includegraphics[width=0.8\linewidth]{...}` (hình lớn) hoặc `[width=0.5\linewidth]` (hình nhỏ)

### Bảng biểu (Tables)
- Caption ở **dưới** bảng (khác với nhiều quy chuẩn khác)
- Số thứ tự: Bảng X.Y (X = chương, Y = thứ tự trong chương)
- Cột header dùng `\textbf{}`
- Bảng đặc tả Use Case: dùng `longtable` để tránh tràn trang

### Đặc tả Use Case (quan trọng — ví dụ dùng bảng, không phải bullet)
```latex
\begin{longtable}{|p{4cm}|p{10cm}|}
\hline
\textbf{Tên Use Case} & Tên UC \\
\hline
\textbf{Tác nhân} & Admin, Operator \\
\hline
\textbf{Tiền điều kiện} & ... \\
\hline
\textbf{Luồng sự kiện chính} & 1. ... \newline 2. ... \\
\hline
\textbf{Luồng ngoại lệ} & ... \\
\hline
\textbf{Hậu điều kiện} & ... \\
\hline
\end{longtable}
```

### Thuật ngữ đúng (sau khi đổi tên)
| Code | Đồ án gọi là | Ý nghĩa |
|------|-------------|---------|
| Project | Chuyến đi / Project | Container lớn, nhiều lượt lặn |
| Trip | Lượt lặn / Trip | Một lần lặn cụ thể |
| ROV | ROV / Phương tiện không người lái | Robot lặn |

---

## PHASE 0 — TIỀN XỬ LÝ (Làm trước tất cả, không viết chapter nào khi chưa xong)

### 0.1 Sửa metadata DoAn.tex
- [ ] Thay `\AUTHOR{NGUYỄN VĂN ABC}` → tên thật sinh viên
- [ ] Kiểm tra `Bia.tex` và `Bia_lot.tex` — điền đầy đủ: tên SV, MSSV, tên GVHD, năm

### 0.2 Populate file .bib
Phải có tối thiểu 15-20 tài liệu tham khảo. Mỗi công nghệ dùng cần 1 citation.

```bibtex
% Ví dụ format IEEE (theo biblatex style=ieee đã cấu hình trong DoAn.tex)
@misc{reactjs,
  author = {{Meta Open Source}},
  title  = {{React} — A JavaScript library for building user interfaces},
  year   = {2024},
  url    = {https://react.dev},
  note   = {Accessed: 2026-06-21}
}
@misc{nodejs,
  author = {{OpenJS Foundation}},
  title  = {{Node.js}},
  year   = {2024},
  url    = {https://nodejs.org},
  note   = {Accessed: 2026-06-21}
}
```

Danh sách citations cần viết:
- `[1]` ReactJS / React 18
- `[2]` Node.js
- `[3]` Express.js
- `[4]` MongoDB
- `[5]` Mongoose ODM
- `[6]` Redis
- `[7]` Bull Queue (trang npm)
- `[8]` AWS S3 Presigned URLs (docs)
- `[9]` JWT RFC 7519
- `[10]` Passport.js
- `[11]` Google OAuth 2.0 (Google Identity docs)
- `[12]` SSE / EventSource spec (MDN hoặc W3C)
- `[13]` Gemini API (Google AI docs)
- `[14]` YOLOv8 / Ultralytics
- `[15]` FastAPI
- `[16]` Z-Score anomaly detection (sách hoặc paper)
- `[17]` Recharts
- `[18]` Leaflet.js
- `[19]` Docker Compose
- `[20]` Tailwind CSS

### 0.3 Điền Tu_viet_tat.tex
Các từ viết tắt cần thêm:
- ROV — Remotely Operated Vehicle
- API — Application Programming Interface
- JWT — JSON Web Token
- SSE — Server-Sent Events
- RBAC — Role-Based Access Control
- ORM — Object-Relational Mapping
- ODM — Object-Document Mapping
- AI — Artificial Intelligence
- LLM — Large Language Model
- YOLO — You Only Look Once
- S3 — Simple Storage Service
- VPS — Virtual Private Server
- MSSV — Mã số sinh viên
- GPS — Global Positioning System
- CSV — Comma-Separated Values
- DVL — Doppler Velocity Log

### 0.4 Chụp ảnh màn hình ứng dụng (cần trước khi viết Ch4)
Start server: `cd backend && npm run dev` + `cd frontend && npm run dev`

Danh sách screenshot cần chụp (lưu vào `Hinhve/`):
| Tên file | Nội dung | Dùng ở |
|----------|---------|--------|
| `ui_dashboard.png` | Dashboard — stat cards + biểu đồ | Ch4 |
| `ui_login.png` | Trang đăng nhập | Ch4 |
| `ui_projects_list.png` | Danh sách Projects | Ch4 |
| `ui_project_detail.png` | ProjectDetailPage — TripCard expanded | Ch4 |
| `ui_trip_cockpit.png` | TripDetailPage — full cockpit layout | Ch4 |
| `ui_cockpit_chart.png` | Bottom chart với anomaly dots | Ch4/Ch5 |
| `ui_cockpit_sonar.png` | SonarViewer panel | Ch4/Ch5 |
| `ui_sensor_upload.png` | Upload modal CSV | Ch4 |
| `ui_ai_analyze.png` | AIAnalyzePopover (confidence slider) | Ch4/Ch5 |
| `ui_evidence_panel.png` | Evidence panel (PHOTO/CLIP badges) | Ch5 |
| `ui_yolo_bbox.png` | Video với bbox detection overlay | Ch5 |
| `ui_ai_summary.png` | AI Summary section trong ProjectDetailPage | Ch5 |
| `ui_rov_list.png` | ROV Registry | Ch4 |
| `ui_dark_mode.png` | Bất kỳ trang nào ở dark mode | Ch4 |
| `ui_notifications.png` | Notification bell + dropdown | Ch4 |
| `ui_audit_log.png` | Audit Log page | Ch4 |
| `ui_media_gallery.png` | Media gallery với lightbox | Ch4 |

### 0.5 Chiến lược vẽ sơ đồ (QUAN TRỌNG)

Chia 2 nhóm dựa trên mức độ cần thẩm mỹ:

**Nhóm A — PlantUML nội dung tham chiếu → Vẽ lại thủ công trong Draw.io:**
Những sơ đồ này chỉ cần đúng nội dung (actor, UC, quan hệ). Layout xấu OK vì sẽ vẽ lại.
| Tên file | Loại | Trạng thái |
|----------|------|-----------|
| `uc_tongquat.png` | UC tổng quát (5 actor, 17 UC) | ✅ Đã có (PlantUML) |
| `uc_phanra_data.png` | UC phân rã — Phân hệ Dữ liệu thực địa | ❌ Cần tạo PlantUML |
| `uc_phanra_ai.png` | UC phân rã — Phân hệ AI Phân tích | ❌ Cần tạo PlantUML |

**Nhóm B — PlantUML vẽ đẹp trực tiếp (không cần vẽ lại):**
Những sơ đồ có cấu trúc rõ ràng, PlantUML render đẹp tự nhiên.
| Tên file | Loại | Trạng thái |
|----------|------|-----------|
| `act_data_workflow.png` | Activity swimlane 3 làn | ✅ Đã có — cần kiểm tra chất lượng |
| `state_project.png` | State diagram vòng đời Project | ✅ Đã có |
| `state_trip.png` | State diagram vòng đời Trip | ✅ Đã có |
| `seq_sensor_upload.png` | Sequence diagram upload CSV | ✅ Đã có |
| `seq_ai_analysis.png` | Sequence diagram YOLO async | ✅ Đã có |
| `arch_tong_quan.png` | Kiến trúc tổng quan Client-Server | ✅ Đã có |
| `arch_module_dep.png` | Module dependency Backend | ✅ Đã có |
| `arch_deploy.png` | Deployment VPS+Docker+Vercel | ✅ Đã có |
| `er_diagram.png` | Entity-Relationship diagram | ✅ Đã có |

### 0.5b Hai biểu đồ UC phân rã cần tạo mới

**Lý do cần 2 (không phải 1):** Hệ thống có 2 phân hệ đột phá riêng biệt, mỗi phân hệ có
actor phụ khác nhau (YOLO Service chỉ tham gia phân hệ AI, không tham gia phân hệ data upload).

**`uc_phanra_data.puml`** — Phân hệ Upload & Quản lý Dữ liệu Thực địa:
- Actor chính: Operator
- UC chi tiết: Tạo Project → Tạo Trip → Upload Sensor CSV (+ overlap warning) →
  Upload DVL JSON → Upload Sonar → Upload Video/Ảnh (presigned S3) →
  Xem biểu đồ cảm biến + Anomaly → Đồng bộ Video--Chart → Trích xuất Bằng chứng
- Include/extend: Đồng bộ <<extend>> Upload Media (cần recordedAt);
  Upload lại cùng tên file <<include>> Xóa data cũ

**`uc_phanra_ai.puml`** — Phân hệ AI Phân tích:
- Actor chính: Operator; Actor phụ: YOLO Service, Gemini AI
- UC chi tiết: Cấu hình model + confidence → Phân tích Media (YOLO) →
  Phân tích Evidence (YOLO clip range) → Xem bbox theo frame →
  Hoàn tất Project → Tạo tóm tắt AI (Gemini) → Tái tạo tóm tắt
- Include/extend: Phân tích Evidence <<extend>> Phân tích Media;
  Tái tạo <<extend>> Tạo tóm tắt AI

Tạo sơ đồ kiến trúc/deploy (Nhóm B, nếu chưa đủ chất lượng):
| Tên file | Loại sơ đồ | Dùng ở |
|----------|-----------|--------|
| `arch_tong_quan.png` | Kiến trúc tổng quan Client-Server-Microservice | Ch4 |
| `arch_module_dep.png` | Module dependency diagram (Backend modules) | Ch4 |
| `arch_deploy.png` | Deployment architecture (VPS+Docker+Vercel) | Ch4 |

### 0.6 Sửa thuật ngữ cũ trong Ch2
- Toàn bộ Ch2: thay "Chuyến đi (Trips) và Lượt lặn (Dives)" → "Chuyến khảo sát (Projects) và Lượt lặn (Trips)"
- Hình 2.2 caption: đổi nếu có "Dives"

---

## PHASE 1 — CÁC TRANG ĐẦU (Lời cảm ơn, Tóm tắt, Abstract)

### 1.1 Lời cảm ơn (`0_2_Loi_cam_on.tex`)
Nội dung: ~200 từ, văn xuôi, không quá dài. Gồm:
- Cảm ơn thầy/cô hướng dẫn (tên GVHD)
- Cảm ơn khoa/trường
- Cảm ơn gia đình, bạn bè
- Cam kết đây là công trình của tác giả

### 1.2 Tóm tắt tiếng Việt (`0_3_Tom_tat_noi_dung.tex`)
Nội dung: 4 đoạn văn xuôi, 200–350 từ. Theo đúng format ví dụ mẫu (trang 4):

**Đoạn 1** — Bối cảnh + vấn đề:
> Quản lý dữ liệu vận hành ROV sau khi thiết bị trở về bờ hiện nay gặp nhiều bất cập: operator phải đối chiếu thủ công video và file CSV cảm biến, không có công cụ số hóa tập trung, thiếu khả năng phân tích tự động...

**Đoạn 2** — Giải pháp đề xuất:
> Đồ án xây dựng hệ thống web quản lý vận hành ROV theo kiến trúc Client-Server đa tầng, tích hợp module AI: (i) nhận diện vật thể dưới nước bằng YOLOv8 chạy trên Python microservice, (ii) tóm tắt nhiệm vụ tự động bằng Gemini 2.5 Flash LLM, (iii) phát hiện bất thường cảm biến bằng Z-Score...

**Đoạn 3** — Kết quả đạt được:
> Hệ thống đã được triển khai thực tế trên VPS, hỗ trợ ba vai trò (Admin/Operator/Viewer), kiểm thử tải Artillery đạt p95 < 500ms dưới 30 concurrent users, YOLO detect ảnh < 1s và video tốc độ X FPS...

**Đoạn 4** — Ứng dụng và hướng phát triển:
> Hệ thống đặt nền móng cho việc số hóa quy trình quản lý ROV, có thể mở rộng tích hợp real-time GCS khi có kết nối mạng ngoài thực địa...

### 1.3 Abstract tiếng Anh (`0_4_Tom_tat_noi_dung_English.tex`)
Dịch Tóm tắt tiếng Việt sang tiếng Anh, cùng format 4 đoạn.

---

## PHASE 2 — CHƯƠNG 1 (Chỉnh sửa nhỏ)

**File:** `Chuong/1_Gioi_thieu.tex`
**Ước tính:** ~3-4 trang, hiện tại ~40 dòng (có thể đã đủ)

### Việc cần làm:
- [ ] Đọc lại toàn bộ, kiểm tra thuật ngữ (Trip→Project, Dive→Trip)
- [ ] Đảm bảo các phần: 1.1 Lý do chọn đề tài, 1.2 Mục tiêu, 1.3 Phạm vi, 1.4 Bố cục đồ án
- [ ] Phần 1.2 phải đề cập đủ 3 nhóm tính năng AI: YOLOv8, Gemini, Z-Score anomaly
- [ ] Câu cuối chương: "Chương tiếp theo sẽ trình bày..."

---

## PHASE 3 — CHƯƠNG 2 (Viết lại đáng kể)

**File:** `Chuong/2_Khao_sat.tex`
**Mục tiêu:** ~15-20 trang (hiện 112 dòng ≈ 4-5 trang, cần 3-4x nhiều hơn)
**Điểm khác biệt lớn nhất so với ví dụ:** Ví dụ dùng bảng cho UC specs + activity diagrams swimlane

### 2.1 Cấu trúc mục tiêu:
```
2.1 Khảo sát hiện trạng           (giữ, expand thêm)
2.2 Tổng quan chức năng           (giữ, fix thuật ngữ)
    2.2.1 Biểu đồ UC tổng quát    (giữ)
    2.2.2 Biểu đồ UC phân rã      (mở rộng — thêm các phân hệ khác)
    2.2.3 Quy trình nghiệp vụ     (upgrade → swimlane activity diagram)
2.3 Đặc tả chức năng             (VIẾT LẠI — dùng bảng thay bullet)
    2.3.1 UC: Đăng nhập
    2.3.2 UC: Tải lên dữ liệu cảm biến
    2.3.3 UC: Kích hoạt phân tích YOLO
    2.3.4 UC: Trích xuất bằng chứng
    2.3.5 UC: Tạo báo cáo AI
    (Xem thêm: Phụ lục B cho CRUD cơ bản)
2.4 Yêu cầu phi chức năng        (giữ, có thể đổi thành bảng)
2.5 Sơ đồ trạng thái             (MỚI — state diagrams)
    2.5.1 Vòng đời Project
    2.5.2 Vòng đời Trip
    2.5.3 Vòng đời Media (phân tích AI)
```

### 2.2 Việc cần làm:

**A. Sửa thuật ngữ:**
- Thay toàn bộ "Trips/Dives" → "Projects/Trips" ("Chuyến khảo sát/Lượt lặn")

**B. Đặc tả UC — đổi từ bullet sang bảng:**

Format mẫu cho mỗi UC (dựa trên ví dụ trang 15-21):
```latex
\begin{table}[H]
\centering
\begin{tabular}{|p{4cm}|p{10cm}|}
\hline
\multicolumn{2}{|c|}{\textbf{Bảng 2.X: Đặc tả Use Case -- [Tên UC]}} \\
\hline
\textbf{Mã Use Case} & UC-0X \\
\hline
\textbf{Tên Use Case} & ... \\
\hline
\textbf{Tác nhân} & Operator, Admin \\
\hline
\textbf{Mô tả} & ... \\
\hline
\textbf{Tiền điều kiện} & ... \\
\hline
\textbf{Luồng sự kiện chính} & 
\begin{enumerate}[leftmargin=*,nosep]
  \item ...
  \item ...
\end{enumerate} \\
\hline
\textbf{Luồng ngoại lệ} & ... \\
\hline
\textbf{Hậu điều kiện} & ... \\
\hline
\end{tabular}
\end{table}
```

UC cần có bảng đặc tả (5 UC chính + Phụ lục B cho CRUD):
- **UC-01**: Đăng nhập (email/password + Google OAuth)
- **UC-02**: Tải lên và đồng bộ dữ liệu cảm biến (sensor CSV upload)
- **UC-03**: Kích hoạt phân tích nhận diện vật thể YOLO
- **UC-04**: Trích xuất và phân tích bằng chứng (Evidence)
- **UC-05**: Tạo báo cáo tóm tắt bằng Gemini AI

**C. Activity diagram swimlane:**
Vẽ lại `uc_quytrinh.png` dạng swimlane với 3 làn:
- **Làn 1**: Operator
- **Làn 2**: Hệ thống (Backend)
- **Làn 3**: AI Services (YOLO + Gemini)

Các bước: Tạo Project → Tạo Trip → Upload CSV + Media → Run YOLO → Run AI Summary → Mark Complete → Download Report

**D. State diagrams (MỚI):**

State diagram cho **Project**:
```
[planning] → [active] → [completed]
                ↓
           [on_hold]
```

State diagram cho **Trip**:
```
[pending] → [in_progress] → [done]
                ↓
           [failed]
```

State diagram cho **Media phân tích**:
```
[pending] → [ready] → [analyzing] → [done]
                           ↓
                        [failed]
```

---

## PHASE 4 — CHƯƠNG 3 (Viết lại hoàn toàn)

**File:** `Chuong/3_Cong_nghe.tex`
**Mục tiêu:** ~8-10 trang (hiện 37 dòng ≈ 2 trang, cần 4-5x)
**Key deliverable:** Bảng 3.1 tổng quan + 5-6 nhóm công nghệ

### 3.1 Cấu trúc mục tiêu (theo ví dụ mẫu trang 26-32):
```
Đoạn mở đầu: 1 đoạn văn giải thích cách tổ chức chương

3.1 Tổng quan lựa chọn công nghệ
    Bảng 3.1: Tổng quan công nghệ theo nhóm chức năng

3.2 Nhóm xử lý nghiệp vụ
    3.2.1 Node.js và Express.js
    3.2.2 Bull Queue

3.3 Nhóm dữ liệu và lưu trữ
    3.3.1 MongoDB và Mongoose
    3.3.2 Redis
    3.3.3 AWS S3

3.4 Giao tiếp thời gian thực và Xác thực
    3.4.1 Server-Sent Events (SSE)
    3.4.2 JWT và Passport.js (bao gồm Google OAuth2)

3.5 Trí tuệ nhân tạo và Xử lý dữ liệu
    3.5.1 YOLOv8 và FastAPI (Python microservice)
    3.5.2 Gemini 2.5 Flash API
    3.5.3 Phát hiện bất thường Z-Score

3.6 Nhóm giao diện người dùng
    3.6.1 React 18 và Vite
    3.6.2 React Query và Zustand
    3.6.3 Recharts và Leaflet.js

3.7 Tích hợp dịch vụ và Triển khai
    Docker Compose, Nginx, Vercel
```

### 3.2 Bảng 3.1 — Template (QUAN TRỌNG):

```latex
\begin{table}[H]
\centering
\begin{tabular}{|p{3cm}|p{4cm}|p{4cm}|p{3cm}|}
\hline
\textbf{Công nghệ} & \textbf{Bài toán giải quyết} & \textbf{Lý do lựa chọn} & \textbf{Thay thế xem xét} \\
\hline
\multicolumn{4}{|l|}{\textit{Nhóm xử lý nghiệp vụ}} \\
\hline
Node.js / Express.js & ... & ... & Django, Spring Boot \\
\hline
Bull Queue & ... & ... & RabbitMQ, Kafka \\
\hline
\multicolumn{4}{|l|}{\textit{Nhóm dữ liệu}} \\
\hline
MongoDB & ... & ... & MySQL, PostgreSQL \\
\hline
Redis & ... & ... & Memcached \\
\hline
AWS S3 & ... & ... & Cloudinary, MinIO \\
\hline
% ... tiếp tục
\end{tabular}
\caption{Tổng quan lựa chọn công nghệ theo nhóm chức năng}
\label{table:tech_overview}
\end{table}
```

### 3.3 Nội dung mỗi subsection — Template (2 đoạn):

**Đoạn 1** — Bài toán + cơ chế hoạt động:
> "Bài toán cốt lõi của tầng máy chủ là [X]. [Tên công nghệ] \cite{key} [cơ chế hoạt động]. [Tính năng cụ thể A, B, C] cho phép [kết quả]."

**Đoạn 2** — Lý do chọn + so sánh thay thế:
> "So với [alternative 1], [tên CN] [ưu điểm cụ thể]. So với [alternative 2], [ưu điểm khác]. Trong dự án này, [tên CN] được chọn vì [lý do chính xác liên quan đến bài toán ROV]."

### 3.4 Nội dung chi tiết từng subsection:

**3.2.1 Node.js và Express.js**
- Bài toán: xử lý I/O bất đồng bộ — nhiều operator upload file CSV lớn đồng thời + maintain SSE connections lâu dài
- Cơ chế: event-driven non-blocking I/O, single thread event loop
- So sánh: Django (synchronous), Spring Boot (multi-thread nặng), FastAPI (async nhưng Python)
- Lý do chọn: phù hợp I/O-heavy workload, hệ sinh thái npm phong phú, SSE native

**3.2.2 Bull Queue**
- Bài toán: tác vụ YOLO analysis mất 10-300s, không thể block HTTP request
- Cơ chế: Redis-backed queue, producer/consumer pattern, retry, delay
- So sánh: RabbitMQ (nặng, cần config), Celery (Python, khác runtime), BullMQ (phiên bản mới hơn)
- Lý do chọn: đơn giản, chạy cùng Redis instance đã có, API TypeScript-friendly

**3.3.1 MongoDB và Mongoose**
- Bài toán: sensor data schema thay đổi theo phần cứng (thêm DVL, Sonar, IMU sensors)
- Cơ chế: document-oriented, schema-less, Time-series collection support
- So sánh: PostgreSQL (rigid schema), MySQL (không phù hợp time-series linh hoạt)
- Lý do chọn: flexible schema cho sensor data, populate() cho references, aggregation pipeline

**3.3.2 Redis**
- Bài toán kép: (i) token blacklist khi logout, (ii) backing store cho Bull Queue
- Cơ chế: in-memory key-value, TTL, pub/sub
- So sánh: Memcached (không hỗ trợ TTL per-key tốt, không có pub/sub)
- Lý do chọn: đa năng — 1 service phục vụ 3 mục đích (blacklist, queue, rate limit)

**3.3.3 AWS S3**
- Bài toán: video ROV có thể 1-10GB/lần lặn, không thể lưu trong DB hay disk server
- Cơ chế: object storage, presigned URL cho client direct upload (bypass server)
- So sánh: Cloudinary (giới hạn free tier, không phù hợp video lớn), MinIO (self-hosted)
- Lý do chọn: mature, reliable, presigned URL giảm tải bandwidth server chính

**3.4.1 Server-Sent Events (SSE)**
- Bài toán: sau khi YOLO/Gemini xong (async), cần push kết quả về browser ngay
- Cơ chế: HTTP long-lived response, text/event-stream, auto-reconnect
- So sánh: WebSocket (bidirectional — overkill cho server→client only), polling (tốn requests)
- Lý do chọn: unidirectional push, đơn giản, native browser support, no library needed

**3.4.2 JWT và Passport.js**
- Bài toán: authentication đa phương thức (email/password + Google OAuth2) + RBAC 3 vai trò
- Cơ chế: access token 15 phút + refresh token 7 ngày + Redis blacklist
- So sánh: session-based (cần sticky session), Keycloak (quá phức tạp cho dự án này)
- Lý do chọn: stateless, scalable, Passport.js hỗ trợ cả local + Google strategy

**3.5.1 YOLOv8 và FastAPI**
- Bài toán: nhận diện vật thể (san hô, mảnh vỡ, sinh vật biển) từ video ROV dưới nước
- Cơ chế: single-pass detection, YOLOv8n (nano - 6MB), FastAPI async endpoints
- So sánh: Faster R-CNN (chậm, 2-stage), YOLOv5 (ít tính năng tracking), Detectron2 (phức tạp)
- Lý do chọn: real-time capable, ByteTrack cho video tracking, CPU inference đủ dùng trên VPS

**3.5.2 Gemini 2.5 Flash API**
- Bài toán: tổng hợp dữ liệu phân tán (sensor stats, anomalies, media count, GPS) → văn bản tóm tắt
- Cơ chế: LLM API, context window lớn, structured prompt
- So sánh: GPT-4o (đắt hơn), Claude Haiku (context nhỏ hơn), mô hình local (cần GPU)
- Lý do chọn: context window 1M token, tốc độ nhanh (Flash), chi phí thấp, free tier đủ cho demo

**3.5.3 Phát hiện bất thường Z-Score**
- Bài toán: tự động flag các điểm đo nhiệt độ/áp suất/độ sâu bất thường mà không cần dán nhãn
- Cơ chế: z = (x - μ) / σ, ngưỡng |z| > 2.5 là outlier
- So sánh: IQR method (kém nhạy với đỉnh nhọn), Isolation Forest (cần training data)
- Lý do chọn: không cần training, tự implement, đủ chính xác cho cảm biến môi trường

**3.6.1 React 18 và Vite**
- Bài toán: UI Cockpit cần cập nhật liên tục (video sync với biểu đồ <100ms) mà không re-render toàn trang
- Cơ chế: Virtual DOM, Concurrent Rendering (React 18), Vite HMR < 50ms
- So sánh: Vue.js (hệ sinh thái chart nhỏ hơn), Angular (boilerplate nhiều), Next.js (SSR không cần thiết)
- Lý do chọn: React hooks phù hợp với complex state (video time sync), Vite nhanh hơn CRA

**3.6.2 React Query và Zustand**
- Bài toán: quản lý dual state — server state (API data) và client state (auth, UI toggles)
- Cơ chế: React Query cache + invalidation, Zustand minimal store với persist
- So sánh: Redux Toolkit (boilerplate), SWR (ít tính năng hơn React Query), Context (re-render nhiều)
- Lý do chọn: phân tách rõ server/client state, staleTime cho cache control, persist cho auth

**3.6.3 Recharts và Leaflet.js**
- Bài toán: biểu đồ time-series cảm biến (nhiệt độ, áp suất, độ sâu) + bản đồ GPS
- Cơ chế: SVG-based charts với animated reference line, Leaflet raw (không dùng react-leaflet)
- So sánh: Chart.js (ít tùy chỉnh), D3.js (quá phức tạp), Google Maps (tốn phí, cần API key)
- Lý do chọn: Recharts tích hợp tốt React, Leaflet + OpenStreetMap miễn phí; raw Leaflet tránh incompatibility với React 18.3

**3.7 Triển khai**
- Docker Compose: backend + yolo-service + redis + nginx
- Nginx: reverse proxy + SSL termination
- Vercel: frontend (CDN edge, CI/CD tự động)
- Lý do dùng VPS thay cloud function: Redis + YOLOv8 cần RAM ~3GB, không có free tier phù hợp

---

## PHASE 5 — CHƯƠNG 4 (Viết lại hoàn toàn — phần lớn nhất)

**File:** `Chuong/4_Ket_qua_thuc_nghiem.tex`
**Mục tiêu:** ~25-30 trang (hiện 90 dòng ≈ 3-4 trang, cần 7-8x)

### 5.1 Cấu trúc mục tiêu:
```
4.1 Thiết kế kiến trúc
    4.1.1 Lựa chọn kiến trúc phần mềm  (viết lại — thêm hình kiến trúc)
    4.1.2 Thiết kế tổng quan           (thêm Hình 4.1 — module dependency)

4.2 Thiết kế chi tiết
    4.2.1 Thiết kế giao diện           (thêm Bảng breakpoints, Bảng màu, Bảng pages, Wireframes)
    4.2.2 Thiết kế hành vi             (Sequence diagrams: sensor upload + YOLO analysis)
    4.2.3 Thiết kế cơ sở dữ liệu      (VIẾT LẠI — bảng chi tiết từng collection)

4.3 Xây dựng ứng dụng
    4.3.1 Công cụ và thư viện          (Bảng tools — giữ nhưng expand)
    4.3.2 Kết quả xây dựng            (MỚI — screenshot UI với mô tả)

4.4 Kiểm thử
    4.4.1 Kiểm thử chức năng (API)     (MỚI — functional test results: 37/37 passed)
    4.4.2 Kiểm thử tải (Load test)     (MỚI — Artillery kết quả thực tế từ CLAUDE.md)

4.5 Triển khai thực nghiệm
    4.5.1 Kiến trúc triển khai         (MỚI — hình deploy diagram)
    4.5.2 Cấu hình môi trường          (viết lại)
```

### 5.2 Thiết kế giao diện (Section 4.2.1):

**Bảng 4.1 — Breakpoints (theo Tailwind CSS):**
| Tên điểm ngắt | Chiều rộng tối thiểu |
|---------------|---------------------|
| sm | 640 px |
| md | 768 px |
| lg | 1024 px |
| xl | 1280 px |
| 2xl | 1400 px |

**Bảng 4.2 — Màu ngữ nghĩa (Design token):**
| Vai trò ngữ nghĩa | Chế độ sáng | Chế độ tối |
|------------------|-------------|-----------|
| bg-background | gray-50 (#F9FAFB) | gray-900 (#111827) |
| bg-card | white (#FFFFFF) | gray-800 (#1F2937) |
| text-foreground | gray-900 (#111827) | gray-50 (#F9FAFB) |
| bg-primary | blue-600 (#2563EB) | blue-500 (#3B82F6) |
| bg-destructive | red-600 (#DC2626) | red-500 (#EF4444) |

**Bảng 4.3 — Danh sách trang theo vai trò:**
| Vai trò | Số trang | Các trang chính |
|---------|----------|----------------|
| Admin | 8 | Dashboard, Projects, Trips, ROVs, Users, Audit Log, Notifications, Profile |
| Operator | 7 | Dashboard, Projects, Trips, ROVs, TripDetail (Cockpit), Notifications, Profile |
| Viewer | 5 | Dashboard, Projects, Trips, ROVs, Profile |

**Wireframe figures (6 hình):**
- Hình 4.2: Dashboard — stat cards + biểu đồ
- Hình 4.3: ProjectDetailPage — TripCard list
- Hình 4.4: TripDetailPage Cockpit — 3-column layout
- Hình 4.5: AI Analyze Popover
- Hình 4.6: Evidence Panel
- Hình 4.7: Dark mode example

### 5.3 Thiết kế cơ sở dữ liệu (Section 4.2.3) — QUAN TRỌNG:

Mỗi collection cần 1 bảng theo format:
```latex
\begin{table}[H]
\centering
\begin{tabular}{|l|l|l|p{5cm}|}
\hline
\textbf{Trường} & \textbf{Kiểu dữ liệu} & \textbf{Ràng buộc} & \textbf{Mô tả} \\
\hline
\_id & ObjectId & PK, auto & Định danh tự động \\
\hline
email & String & unique, required & Địa chỉ email đăng nhập \\
\hline
...
\end{tabular}
\caption{Cấu trúc collection \texttt{users}}
\label{table:db_users}
\end{table}
```

Collections cần có bảng thiết kế (8 collection chính):
1. **users** — _id, email, fullName, password, role, isActive, googleId, authProvider, lastLoginAt
2. **rovs** — _id, name, model, serialNumber, status, notes, createdBy
3. **projects** — _id, name, rov, location, gpsLocation, status, startTime, endTime, aiSummary{content/status/generatedAt}, createdBy
4. **trips** — _id, project, title, description, status, gpsLocation, locationName, sensorCount, sonarCount, dvlCount, createdBy
5. **sensordatas** — _id, trip, timestamp, depth, temp, pressure, yaw, pitch, roll, voltage, battery_percent, humidity, sourceFile
6. **media** — _id, trip, s3Key, url, type, size, status, order, originalName, recordedAt, duration, labels[{name/confidence/bbox/frameTime/trackId}], analysisStatus
7. **snapshots** — _id, type, trip, project, parentMediaId, imageS3Key, imageTime, startTime, endTime, thumbnailS3Key, aiLabels, analysisStatus, note
8. **notifications** — _id, userId, type, title, body, isRead, link
9. **auditlogs** — _id, action, entity, entityId, userId, details, createdAt

### 5.4 Sequence Diagrams (Section 4.2.2):

**Hình 4.X: Sequence diagram — Luồng tải lên dữ liệu cảm biến**
```
Operator → Frontend: Chọn file CSV
Frontend → Frontend: Parse + validate columns
Frontend → Backend: POST /trips/:id/sensor-data/upload {readings, sourceFile}
Backend → Backend: Z-Score anomaly detection
Backend → MongoDB: bulkInsert SensorData
Backend → NominatimAPI: Reverse geocoding GPS
Backend → MongoDB: Update trip.locationName
Backend → Frontend: 200 {count, anomalies, warning?}
Frontend → Operator: Toast + Chart render
```

**Hình 4.X+1: Sequence diagram — Luồng phân tích YOLO**
```
Operator → Frontend: Click "Run Analysis" {model, confidence}
Frontend → Backend: POST /media/:id/analyze
Backend → MongoDB: media.analysisStatus = 'pending'
Backend → Bull Queue: enqueue job {mediaId, model, confidence}
Backend → Frontend: 202 Accepted
-- async --
Worker → S3: Get presigned URL
Worker → YoloService: POST /detect {mediaUrl, model, confidence}
YoloService → Worker: [{name, confidence, bbox, frameTime, trackId}]
Worker → MongoDB: media.labels = [...], analysisStatus = 'done'
Worker → SSE: push event 'media_analysis_done' to userId
Frontend → Frontend: invalidate ['media'] cache
Frontend → Operator: Labels appear on video
```

### 5.5 Screenshots UI với mô tả (Section 4.3.2):

Ít nhất 8-10 hình màn hình thực tế, mỗi hình có 2-3 câu mô tả:
- Hình 4.X: Dashboard với stat cards và biểu đồ thống kê theo 6 tháng
- Hình 4.X: TripDetailPage Cockpit — layout 3 cột, trình phát video + biểu đồ cảm biến đồng bộ
- Hình 4.X: Sensor chart với anomaly dots màu đỏ và panel "Anomalies Detected"
- Hình 4.X: SonarViewer phát file sonar binary
- Hình 4.X: Evidence Panel với thumbnail PHOTO và CLIP
- Hình 4.X: AI Analyze Popover với confidence slider
- Hình 4.X: Video với bounding box YOLO overlay
- Hình 4.X: AI Summary trong ProjectDetailPage
- Hình 4.X: Dark mode

### 5.6 Kết quả kiểm thử (Section 4.4):

**Bảng 4.X — Kết quả kiểm thử chức năng:**
| Nhóm | Số test case | Passed | Failed |
|------|-------------|--------|--------|
| Authentication | 7 | 7 | 0 |
| RBAC | 6 | 6 | 0 |
| Validation | 5 | 5 | 0 |
| CRUD | 11 | 11 | 0 |
| Pagination | 6 | 6 | 0 |
| **Tổng** | **35** | **35** | **0** |

**Bảng 4.X+1 — Kết quả kiểm thử tải (Artillery):**
| Endpoint | Avg (ms) | P95 (ms) | Đánh giá |
|----------|---------|---------|---------|
| GET /auth/me | 138 | 448 | Tốt |
| GET /media/trip/:id | 161 | 784 | Tốt |
| GET /trips/:id/sensor-data | 301 | 525 | Chấp nhận |
| GET /stats/overview | 906 | 1842 | Cần tối ưu |

> Lưu ý: Thêm hình chụp màn hình kết quả Artillery nếu có (Artillery HTML report)

---

## PHASE 6 — CHƯƠNG 5 (Kiểm tra + bổ sung)

**File:** `Chuong/5_Giai_phap_dong_gop.tex`
**Mục tiêu:** ~8-10 trang

### Cấu trúc mục tiêu (pattern: Bài toán → Giải pháp → Kết quả):
```
5.1 Đồng bộ video-cảm biến theo thời gian thực
    Bài toán: Operator phải đối chiếu thủ công video + CSV
    Giải pháp: media.recordedAt + ReferenceLine Recharts + useRef video
    Kết quả: Chart scrubs real-time, drift <100ms (Hình 5.1)

5.2 Nhận diện vật thể dưới nước bằng YOLOv8
    Bài toán: Hàng giờ video phải xem thủ công để tìm vật thể
    Giải pháp: YOLOv8n Python microservice + Bull Queue async + per-frame bbox tracking
    Kết quả: Detect ảnh <1s, video sampling tại X FPS, labels hiện theo frame (Hình 5.2)

5.3 Hệ thống bằng chứng (Evidence System)
    Bài toán: Không có cơ chế đánh dấu và lưu trữ phát hiện quan trọng
    Giải pháp: Photo snapshot (canvas → S3) + Clip (startTime/endTime)
    Kết quả: Evidence lưu S3, re-analyze riêng, export (Hình 5.3)

5.4 Phát hiện bất thường cảm biến tự động
    Bài toán: Anomaly phải tìm thủ công trong hàng nghìn dòng CSV
    Giải pháp: Z-Score |z| > 2.5 tại backend, highlight đỏ trên chart
    Kết quả: Anomaly detect tự động, panel list + visual highlight (Hình 5.4)

5.5 Tóm tắt nhiệm vụ bằng LLM
    Bài toán: Báo cáo sau chuyến đi tốn nhiều thời gian viết thủ công
    Giải pháp: Gemini 2.5 Flash + Bull Queue + structured prompt
    Kết quả: ~5-15s sinh báo cáo, lưu DB, SSE push (Hình 5.5)
```

Mỗi contribution cần 1 hình minh họa kết quả thực tế.

---

## PHASE 7 — CHƯƠNG 6 (Chỉnh sửa nhỏ)

**File:** `Chuong/6_Ket_luan.tex`
**Hiện trạng:** 23 dòng — có thể OK nhưng cần kiểm tra

### Cấu trúc cần có:
```
6.1 Kết luận
    - Tóm tắt những gì đã làm được (liệt kê 5-6 điểm)
    - Kết quả đánh giá định lượng (test: 35/35 passed, load test p95 < 500ms)

6.2 Hướng phát triển
    - Real-time GCS integration khi có wifi ngoài thực địa
    - Fine-tune YOLOv8 với dataset ROV thực tế (coral, debris classification)
    - Mobile app cho operator ngoài thực địa
    - Meta_data.json manifest auto-parse
    - Horizontal scaling (Redis Cluster, multiple Node instances)
```

---

## PHASE 8 — PHỤ LỤC B (Đặc tả UC CRUD cơ bản)

**File:** `Chuong/Phu_luc_B.tex`
Đổi toàn bộ từ bullet list sang bảng LaTeX (cùng format như Section 5.3 của plan này).

UC cần có bảng trong Phụ lục B:
- UC: Đăng ký tài khoản
- UC: Quản lý ROV (CRUD)
- UC: Tạo Project
- UC: Tạo Trip trong Project
- UC: Upload Media
- UC: Quản lý người dùng (Admin)
- UC: Xem Audit Log (Admin)
- UC: Xem Dashboard

---

## PHASE 9 — TÀI LIỆU THAM KHẢO

File: `Danh_sach_tai_lieu_tham_khao.bib`

Format IEEE theo `biblatex`:
- `@misc` cho website/docs
- `@article` cho paper học thuật (Z-Score, YOLO paper)
- `@book` cho sách giáo khoa

Cần có citation cho YOLOv8 paper gốc:
```bibtex
@misc{yolov8,
  author = {Jocher, Glenn and Chaurasia, Ayush and Qiu, Jing},
  title  = {Ultralytics {YOLOv8}},
  year   = {2023},
  url    = {https://github.com/ultralytics/ultralytics}
}
```

---

## THỨ TỰ THỰC HIỆN ĐỀ XUẤT

```
TUẦN 1:
  □ Phase 0: Sửa metadata, populate .bib, Tu_viet_tat
  □ Phase 0: Chụp ảnh màn hình (chạy app trên local)
  □ Phase 0: Vẽ sơ đồ kiến trúc + deploy diagram (draw.io)

TUẦN 2:
  □ Phase 1: Lời cảm ơn + Tóm tắt VN + Abstract EN
  □ Phase 4: Viết lại Chương 3 hoàn toàn

TUẦN 3:
  □ Phase 3: Sửa Chương 2 — đổi UC sang bảng
  □ Phase 3: Vẽ activity diagram swimlane + state diagrams

TUẦN 4:
  □ Phase 5: Viết Chương 4 — 4.1 + 4.2 (kiến trúc + DB schema + sequence)

TUẦN 5:
  □ Phase 5: Viết Chương 4 — 4.3 + 4.4 + 4.5 (UI screenshots + test results + deploy)

TUẦN 6:
  □ Phase 6: Kiểm tra + bổ sung Chương 5
  □ Phase 7: Kiểm tra Chương 6
  □ Phase 8: Phụ lục B → bảng
  □ Phase 2: Kiểm tra Chương 1

TUẦN 7:
  □ Compile LaTeX, kiểm tra lỗi, format
  □ Đọc lại toàn bộ, sửa lỗi chính tả
  □ Kiểm tra cross-reference (hình, bảng, citation)
  □ In thử, review layout
```

---

## CHECKLIST CUỐI (Trước khi nộp)

### Nội dung
- [ ] Tất cả UC specs dùng bảng (không còn bullet list)
- [ ] Bảng 3.1 tổng quan công nghệ (4 cột)
- [ ] Tất cả collection MongoDB có bảng thiết kế
- [ ] Có ít nhất 2 sequence diagrams
- [ ] Có ít nhất 1 activity diagram swimlane
- [ ] Có ít nhất 2 state diagrams
- [ ] Có ít nhất 8 UI screenshots thực tế
- [ ] Kết quả kiểm thử chức năng (table)
- [ ] Kết quả kiểm thử tải (table + hình Artillery nếu có)
- [ ] Tóm tắt + Abstract đã viết
- [ ] Lời cảm ơn đã viết
- [ ] Tài liệu tham khảo ≥ 15 entries

### Kỹ thuật LaTeX
- [ ] `\AUTHOR{}` đã điền tên thật
- [ ] `Bia.tex` đầy đủ thông tin (MSSV, GVHD, năm)
- [ ] Tất cả hình vẽ tồn tại trong `Hinhve/`
- [ ] Tất cả `\cite{}` có entry trong `.bib`
- [ ] Tất cả `\ref{}` và `\label{}` khớp nhau
- [ ] Compile không có lỗi, warning về missing reference
- [ ] Danh mục hình vẽ tự động chính xác
- [ ] Danh mục bảng biểu tự động chính xác
- [ ] Từ viết tắt đầy đủ

### Format
- [ ] Thuật ngữ nhất quán: Project/Trip (không còn Trip/Dive)
- [ ] Caption hình đặt dưới hình
- [ ] Caption bảng đặt dưới bảng  
- [ ] Số trang bắt đầu từ trang 1 sau mục lục
- [ ] Header footer đúng

---

*Cập nhật lần cuối: 2026-06-21*
